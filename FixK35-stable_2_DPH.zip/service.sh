#!/system/bin/sh
#sleep 25
sh /system/etc/.nth_fc/.fc_main.sh

