chmod 644 $system/etc/vintf/manifest/manifest_media_c2_software.xml
chmod 755 $system/bin/netd

