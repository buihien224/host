print "╔══╗"
print "╚╗╔╝"
print "╔╝(¯`v´¯)"
print "╚══`.¸.[FixK35]"
print "╲┏━┳━━━━━━━━┓╲╲ "
print "╲┃◯┃╭┻┻╮╭┻┻╮┃╲╲ "
print "╲┃╮┃┃╭╮┃┃╭╮┃┃╲╲"
print "╲┃╯┃┗┻┻┛┗┻┻┻┻╮╲"
print "╲┃◯┃╭╮╰╯┏━━━┳╯╲"
print "╲┃╭┃╰┏┳┳┳┳┓◯┃╲╲  "
print "╲┃╰┃◯╰┗┛┗┛╯╭┃╲╲"
print "╲Telegram: @bhlnk╲"
print "╲╲╲╲╲╲╲╲╲╲╲╲╲╲╲"
print "Let me be a banana        "    
print " "

chmod 644 $MODPATH/system/etc/vintf/manifest/manifest_media_c2_software.xml
chmod 755 $MODPATH/system/bin/netd
rm -rf /data/system/package_cache/*