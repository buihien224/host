
SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=true

LATESTARTSERVICE=false

REPLACE="
"
rm -rf /data/resource-cache/*
rm -rf /data/system/package-cache
